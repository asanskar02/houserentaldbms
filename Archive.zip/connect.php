<?php
$servername = "localhost";
$username = "id20189430_ahouserentals";
$password = "Dhruvm@lhotra09";
$db="id20189430_houserentals";

// Create connection
$conn = new mysqli($servername, $username, $password,$db);

// Check connection
if ($conn -> connect_errno) {
  echo "Failed to connect to MySQL: " . $conn -> connect_error;
  exit();
}

        $name = $_POST['name'];
        $email  = $_POST['email'];
       
        $subject = $_POST['subject'];
        $message= $_POST['message'];
        
        $qry = "INSERT INTO table1 (`name`, `email`,`subject`, `message`) VALUES ('$name','$email', '$subject',' $message')";
        
        if ($conn->query($qry) === TRUE) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $qry . "<br>" . $conn->error;
        }
            
            
?>