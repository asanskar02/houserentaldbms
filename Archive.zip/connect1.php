<?php
$servername = "localhost";
$username = "id20189430_ahouserentals";
$password = "Dhruvm@lhotra09";
$db="id20189430_houserentals";

// Create connection
$conn = new mysqli($servername, $username, $password,$db);

// Check connection
if ($conn -> connect_errno) {
  echo "Failed to connect to MySQL: " . $conn -> connect_error;
  exit();
}
        $email  = $_POST['email'];
        $price  = $_POST['price'];
        $location  = $_POST['location'];
        $message= $_POST['message'];
        
        $qry = "INSERT INTO table2 ( `email`, `price`, `location`, `message`) VALUES ('$email','$price', '$location',' $message')";
        
        if ($conn->query($qry) === TRUE) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $qry . "<br>" . $conn->error;
        }
            
            
?>